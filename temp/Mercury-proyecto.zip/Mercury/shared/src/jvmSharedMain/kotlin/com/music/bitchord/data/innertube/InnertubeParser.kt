package com.music.bitchord.data.innertube

import com.music.bitchord.auth.normalizeDataSyncId
import com.music.bitchord.data.model.Account
import com.music.bitchord.data.model.AccountChannel
import com.music.bitchord.data.model.ArtistNameIndex
import com.music.bitchord.data.model.ArtistPage
import com.music.bitchord.data.model.ArtistRef
import com.music.bitchord.data.model.completeArtistCredits
import com.music.bitchord.data.model.BrowseItem
import com.music.bitchord.data.model.BrowseType
import com.music.bitchord.data.model.HomeShelf
import com.music.bitchord.data.model.LibraryState
import com.music.bitchord.data.model.LikeStatus
import com.music.bitchord.data.model.MoodGenre
import com.music.bitchord.data.model.MoodGenreSection
import com.music.bitchord.data.model.SearchResult
import com.music.bitchord.data.model.ShelfItem
import com.music.bitchord.data.model.shelfLayoutFor
import com.music.bitchord.data.model.Song
import com.music.bitchord.data.model.SongMenu
import com.music.bitchord.data.model.SubscriptionState
import com.music.bitchord.data.model.UserPlaylist
import com.music.bitchord.data.model.VersionPair
import com.music.bitchord.data.model.VersionTimeMap
import com.music.bitchord.data.model.WatchTarget
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import java.util.Locale

/**
 * Innertube responses are deeply nested and their shape drifts between
 * layouts (single-column vs two-column browse, shelf vs carousel). Rather
 * than hard-coding every path, structured parsing is used where the layout
 * is stable (search, home) and a recursive scan where it is not (playlists,
 * library) — see [collectSongsDeep].
 */
object InnertubeParser {

    // ---- Search -------------------------------------------------------------

    fun parseSearchSongs(response: JsonObject): List<Song> =
        parseSearch(response).filterIsInstance<SearchResult.Track>().map { it.song }

    /** One page of search rows, plus the token for the next page if YouTube offers one. */
    data class SearchPage(val rows: List<SearchResult>, val continuation: String?)

    /**
     * Search results are heterogeneous: songs carry a videoId, while albums,
     * artists and playlists carry a browseId plus a page type. Both arrive as
     * `musicResponsiveListItemRenderer`, so each row is classified on the way out.
     */
    fun parseSearch(response: JsonObject): List<SearchResult> = parseSearchPage(response).rows

    fun parseSearchPage(response: JsonObject, includeVideos: Boolean = false): SearchPage {
        // The "All" tab spreads results across several shelf types (card shelf
        // for the top result, then one shelf per category). Its promoted top
        // result lives on the card itself, not in a responsive row, so read it
        // first before walking the ordinary result rows.
        val topResults: List<SearchResult> = if (includeVideos) emptyList() else {
            collectRenderers(response, "musicCardShelfRenderer")
                .mapNotNull { card ->
                    parseCardShelfSong(card)?.let(SearchResult::TopTrack)
                        ?: parseCardShelfBrowse(card)?.let(SearchResult::Browse)
                }
        }
        val rows = collectRenderers(response, "musicResponsiveListItemRenderer")

        // The rows tucked inside an artist's promoted card, paired with the
        // credit that card bills them to — see [cardShelfCredit]. Matched by
        // identity below, because these are the same renderer objects the walk
        // above already found; a card row is just a row that also sits here.
        val cardCredits: List<Pair<JsonObject, Credits>> = if (includeVideos) emptyList() else {
            collectRenderers(response, "musicCardShelfRenderer").flatMap { card ->
                val credit = cardShelfCredit(card) ?: return@flatMap emptyList()
                collectRenderers(card, "musicResponsiveListItemRenderer").map { it to credit }
            }
        }

        val seen = HashSet<String>()
        val parsed = buildList {
            topResults.forEach { result ->
                when (result) {
                    is SearchResult.TopTrack -> {
                        // The mixed All page stays music-only; music-video uploads
                        // belong exclusively to the dedicated Videos tab.
                        if (!result.song.isVideo && seen.add("v:${result.song.videoId}")) add(result)
                    }
                    is SearchResult.Browse -> {
                        if (seen.add("b:${result.item.browseId}")) add(result)
                    }
                    is SearchResult.Track -> Unit
                }
            }
            rows.forEach { renderer ->
            // Browse rows are tested first: an album row also carries a
            // "play album" videoId in its overlay, so checking for a track
            // first would misread every album as a single song.
                val browse = parseBrowseItem(renderer)
                if (browse != null) {
                    if (seen.add("b:${browse.browseId}")) add(SearchResult.Browse(browse))
                } else {
                    val fallback = cardCredits.firstOrNull { it.first === renderer }?.second
                    parseResponsiveListItem(renderer, fallback ?: Credits())?.let { song ->
                        // The mixed All page stays music-only; the dedicated Videos
                        // filter is the one place music-video uploads belong.
                        if (song.isVideo == includeVideos && seen.add("v:${song.videoId}")) {
                            add(SearchResult.Track(song))
                        }
                    }
                }
            }
        }
        return SearchPage(parsed, continuationToken(response))
    }

    /**
     * The typeahead queries out of a `music/get_search_suggestions` response.
     *
     * Two sections come back. The first is what this reads: query strings, as
     * `searchSuggestionRenderer`. The second — present signed in, and for
     * some terms signed out — is entity rows for songs and artists, as the
     * same `musicResponsiveListItemRenderer` a search result uses. Those are
     * deliberately ignored: what the field is being filled in with is a
     * query, and a row that navigates straight to a track instead is a
     * different feature with a different tap target.
     *
     * `searchEndpoint.query` is preferred over the display text because the
     * display text arrives split into runs purely so the typed prefix can be
     * bold-faced, with no separator of its own to rejoin on.
     */
    fun parseSearchSuggestions(response: JsonObject): List<String> =
        collectRenderers(response, "searchSuggestionRenderer")
            .mapNotNull { renderer ->
                val query = renderer.o("navigationEndpoint").o("searchEndpoint").s("query")
                    ?: renderer.o("suggestion").runs()
                query.takeIf { it.isNotBlank() }
            }
            .distinct()

    /** Depth-first collection of a named renderer, preserving document order. */
    private fun collectRenderers(root: JsonElement, name: String): List<JsonObject> {
        val out = mutableListOf<JsonObject>()
        fun walk(node: JsonElement) {
            when (node) {
                is JsonObject -> {
                    (node[name] as? JsonObject)?.let(out::add)
                    node.values.forEach(::walk)
                }
                is JsonArray -> node.forEach(::walk)
                else -> Unit
            }
        }
        walk(root)
        return out
    }

    private fun parseBrowseItem(renderer: JsonObject): BrowseItem? {
        val endpoint = renderer.o("navigationEndpoint").o("browseEndpoint") ?: return null
        val browseId = endpoint.s("browseId") ?: return null
        val pageType = endpoint.o("browseEndpointContextSupportedConfigs")
            .o("browseEndpointContextMusicConfig").s("pageType").orEmpty()

        val columns = renderer.a("flexColumns").orEmpty()
        val title = columns.getOrNull(0)
            .o("musicResponsiveListItemFlexColumnRenderer").o("text").runs()
        if (title.isBlank()) return null

        val subtitle = columns.getOrNull(1)
            .o("musicResponsiveListItemFlexColumnRenderer").o("text").runs()
        // A playlist/album billed as a video chart/compilation — "N videos"
        // in the subtitle, or "video" right in the title, e.g. "Daily Top
        // Music Videos" — would have every row dropped by
        // parseResponsiveListItem anyway, so skip the dead-end card rather
        // than link to an empty page.
        if (VIDEO_WORD.containsMatchIn(title) || VIDEO_WORD.containsMatchIn(subtitle)) return null

        return BrowseItem(
            browseId = browseId,
            title = title,
            subtitle = subtitle,
            thumbnailUrl = renderer.o("thumbnail").o("musicThumbnailRenderer")
                .o("thumbnail").a("thumbnails").best(),
            type = when {
                "ALBUM" in pageType -> BrowseType.ALBUM
                "ARTIST" in pageType -> BrowseType.ARTIST
                "PLAYLIST" in pageType -> BrowseType.PLAYLIST
                else -> BrowseType.OTHER
            },
        )
    }

    // ---- Home feed ----------------------------------------------------------

    fun parseHome(response: JsonObject): List<HomeShelf> {
        val sections = response.o("contents")
            .o("singleColumnBrowseResultsRenderer").a("tabs")?.firstOrNull()
            .o("tabRenderer").o("content").o("sectionListRenderer").a("contents")
            .orEmpty()

        return sections.mapNotNull { section ->
            section.o("musicCarouselShelfRenderer")?.let(::carouselShelf)
                ?: section.o("musicShelfRenderer")?.let(::plainShelf)
        }
    }

    /**
     * The Moods & genres browse page is a set of navigation-button grids, not
     * a normal carousel. Keep the browse params on every button: they select
     * the playlist shelves that belong to that exact mood or genre.
     *
     * A signed-in page leads with a personalised "For you" grid, which is only
     * shortcuts to buttons the Moods and Genres grids already hold. It's
     * dropped: Explore shows the full set once, not a second copy of a few.
     * The heading is localised, so it's recognised by repeating a later
     * section's button, with the English title as a backstop.
     */
    fun parseMoodAndGenres(response: JsonObject): List<MoodGenreSection> {
        val sections = response.o("contents")
            .o("singleColumnBrowseResultsRenderer").a("tabs")?.firstOrNull()
            .o("tabRenderer").o("content").o("sectionListRenderer").a("contents")
            .orEmpty()
        val parsed = sections.mapNotNull { section ->
            val grid = section.o("gridRenderer") ?: return@mapNotNull null
            val title = grid.o("header").o("gridHeaderRenderer").o("title").runs()
            val items = grid.a("items").orEmpty().mapNotNull { item ->
                val button = item.o("musicNavigationButtonRenderer") ?: return@mapNotNull null
                val endpoint = button.o("clickCommand").o("browseEndpoint")
                    ?: button.o("navigationEndpoint").o("browseEndpoint")
                    ?: return@mapNotNull null
                val browseId = endpoint.s("browseId") ?: return@mapNotNull null
                val label = button.o("buttonText").runs().takeIf { it.isNotBlank() }
                    ?: return@mapNotNull null
                MoodGenre(
                    title = label,
                    browseId = browseId,
                    params = endpoint.s("params"),
                    stripeColor = button.o("solid").s("leftStripeColor")?.toLongOrNull(),
                )
            }
            if (title.isBlank() || items.isEmpty()) null else MoodGenreSection(title, items)
        }
        return parsed.filterIndexed { index, section ->
            val later = parsed.drop(index + 1)
                .flatMapTo(HashSet()) { it.items.map { item -> item.browseId to item.params } }
            val shortcuts = section.items.any { (it.browseId to it.params) in later }
            !shortcuts && !section.title.equals("For you", ignoreCase = true)
        }
    }

    /**
     * More Home shelves off a continuation response.
     *
     * Unlike the first page, a continuation envelope doesn't repeat the
     * tabs/section-list wrapper [parseHome] reads off a fixed path — so the
     * shelves are walked out wherever they land instead, the same tradeoff
     * [collectSongsDeep] makes for song rows. Preserves the order they were
     * found in, since a carousel and a plain shelf never share a parent node.
     */
    fun parseHomeContinuation(root: JsonElement): List<HomeShelf> {
        val out = mutableListOf<HomeShelf>()
        fun walk(node: JsonElement) {
            when (node) {
                is JsonObject -> {
                    (node["musicCarouselShelfRenderer"] as? JsonObject)
                        ?.let(::carouselShelf)?.let(out::add)
                    (node["musicShelfRenderer"] as? JsonObject)
                        ?.let(::plainShelf)?.let(out::add)
                    node.values.forEach(::walk)
                }
                is JsonArray -> node.forEach(::walk)
                else -> Unit
            }
        }
        walk(root)
        return out
    }

    private fun carouselShelf(carousel: JsonObject): HomeShelf? {
        val header = carousel.o("header").o("musicCarouselShelfBasicHeaderRenderer")
        val title = header.o("title").runs()
        val strapline = header.o("strapline").runs()
        val contents = carousel.a("contents").orEmpty()
        val parsed = contents.mapNotNull { item ->
            parseTwoRowItem(item.o("musicTwoRowItemRenderer"))
                ?: parseResponsiveListItem(item.o("musicResponsiveListItemRenderer"))
                    ?.let { song ->
                        ShelfItem(song.title, song.artist, song.thumbnailUrl, song.videoId, null, isVideo = song.isVideo)
                    }
                // A chart row with nothing to play — "Top artists" lists the
                // artist alone, no track — falls through parseResponsiveListItem
                // (it demands a videoId) and used to drop the whole shelf.
                ?: parseArtistRow(item.o("musicResponsiveListItemRenderer"))
        }
        // A shelf billed as videos ("Video charts", "Recommended music videos")
        // keeps the videos it can play and loses the video compilations, which
        // open onto pages with nothing on them.
        val items = if (VIDEO_WORD.containsMatchIn(title)) parsed.filter { it.videoId != null } else parsed
        if (items.isEmpty()) return null
        val shelfTitle = title.ifBlank { "For you" }
        val fromList = contents.firstOrNull().o("musicResponsiveListItemRenderer") != null
        return HomeShelf(shelfTitle, items, strapline, layout = shelfLayoutFor(shelfTitle, items, fromList))
    }

    private fun plainShelf(shelf: JsonObject): HomeShelf? {
        val title = shelf.o("title").runs()
        val items = shelf.a("contents").orEmpty().mapNotNull {
            parseResponsiveListItem(it.o("musicResponsiveListItemRenderer"))
        }.map { ShelfItem(it.title, it.artist, it.thumbnailUrl, it.videoId, null, isVideo = it.isVideo) }
        if (items.isEmpty()) return null
        val shelfTitle = title.ifBlank { "For you" }
        return HomeShelf(shelfTitle, items, layout = shelfLayoutFor(shelfTitle, items, fromList = true))
    }

    /**
     * Artist landing page: a "Top songs" shelf (only ~5 rows, but its header
     * links to a playlist with the full list) plus carousels for Albums,
     * Singles & EPs and friends.
     */
    fun parseArtistPage(response: JsonObject): ArtistPage {
        val sections = response.o("contents")
            .o("singleColumnBrowseResultsRenderer").a("tabs")?.firstOrNull()
            .o("tabRenderer").o("content").o("sectionListRenderer").a("contents")
            .orEmpty()

        val songs = mutableListOf<Song>()
        var moreSongs: String? = null
        val shelves = mutableListOf<HomeShelf>()
        val header = response["header"]
        // "Top songs" rows are billed by the page they sit on: the subtitle
        // beside them counts plays where a search row names the artist.
        val credit = Credits(artistName = artistName(header))

        sections.forEach { section ->
            section.o("musicShelfRenderer")?.let { shelf ->
                shelf.a("contents").orEmpty().forEach { row ->
                    parseResponsiveListItem(row.o("musicResponsiveListItemRenderer"), credit)
                        ?.let(songs::add)
                }
                if (moreSongs == null) {
                    moreSongs = shelf.o("title").a("runs")?.firstOrNull()
                        .o("navigationEndpoint").o("browseEndpoint").s("browseId")
                }
            }
            section.o("musicCarouselShelfRenderer")?.let { carousel ->
                val header = carousel.o("header").o("musicCarouselShelfBasicHeaderRenderer")
                val title = header.o("title").runs()
                // Releases and playlists open their pages; the Videos shelf's
                // cards play, now that the player can show them.
                val items = carousel.a("contents").orEmpty().mapNotNull {
                    parseTwoRowItem(it.o("musicTwoRowItemRenderer"))
                }.filter { it.browseId != null || it.isVideo }
                val moreEndpoint = header.o("title").a("runs")?.firstNotNullOfOrNull {
                    it.o("navigationEndpoint").o("browseEndpoint")
                }
                    ?: header.o("moreContentButton").o("buttonRenderer")
                        .o("navigationEndpoint").o("browseEndpoint")
                    ?: header.o("moreContentButton").o("musicMoreContentButtonRenderer")
                        .o("navigationEndpoint").o("browseEndpoint")
                    ?: header.a("endIcons")?.firstNotNullOfOrNull {
                        it.o("musicNavigationButtonRenderer").o("clickCommand").o("browseEndpoint")
                            ?: it.o("musicNavigationButtonRenderer").o("navigationEndpoint").o("browseEndpoint")
                    }
                    ?: header.o("navigationEndpoint").o("browseEndpoint")
                val moreBrowseId = moreEndpoint.s("browseId")
                val moreParams = moreEndpoint.s("params")
                if (title.isNotBlank() && items.isNotEmpty()) {
                    shelves += HomeShelf(
                        title = title,
                        items = items,
                        moreBrowseId = moreBrowseId,
                        moreParams = moreParams,
                        layout = shelfLayoutFor(title, items, fromList = false),
                    )
                }
            }
        }
        return ArtistPage(
            songs, moreSongs, shelves,
            thumbnailUrl = artistThumbnail(header),
            name = credit.artistName,
            description = parseDescription(response),
            subscriberCountText = subscriberCount(header),
            monthlyListenerCount = monthlyListeners(header),
            subscription = subscription(header),
            radio = headerWatchTarget(header, "startRadioButton"),
            shuffle = headerWatchTarget(header, "playButton"),
        )
    }

    /**
     * The queue behind one of the artist header's buttons — `startRadioButton`
     * is Mix (an `RDEM…` radio), `playButton` is Shuffle (`RDAO…`). Both are a
     * `watchEndpoint` carrying a seed track and params; the params arrive
     * percent-encoded and are decoded here, since `next` wants them as base64.
     */
    private fun headerWatchTarget(header: JsonElement?, button: String): WatchTarget? {
        val endpoint = header.o("musicImmersiveHeaderRenderer").o(button)
            .o("buttonRenderer").o("navigationEndpoint").o("watchEndpoint")
            ?: return null
        val playlistId = endpoint.s("playlistId") ?: return null
        return WatchTarget(
            playlistId = playlistId,
            videoId = endpoint.s("videoId"),
            params = endpoint.s("params")?.let { java.net.URLDecoder.decode(it, "UTF-8") },
        )
    }

    /**
     * Every card on a page of two-row items, wherever it sits — a carousel on
     * Home, a grid on a "More" page such as Mixed for you. Used where the
     * caller wants the cards and not the shelves they came in.
     */
    fun parseTwoRowItemsDeep(root: JsonElement): List<ShelfItem> =
        collectRenderers(root, "musicTwoRowItemRenderer").mapNotNull(::parseTwoRowItem)

    /**
     * The header's subscribe button, as state rather than as a label — see
     * [SubscriptionState].
     *
     * Same two shapes [subscriberCount] has to cope with, and read in the same
     * order. The channel id is taken off the button rather than off the browse
     * id the page was fetched with: they are usually the same `UC…`, but a page
     * reached through one of YouTube's aliases is the case where they aren't,
     * and the button is the side that knows what it would act on.
     */
    private fun subscription(header: JsonElement?): SubscriptionState? {
        val immersive = header.o("musicImmersiveHeaderRenderer") ?: return null
        // Both shapes are tried rather than the first one found being trusted:
        // the newer button is sometimes only the count, and a page that ships
        // both is one where the state is on the other one.
        return listOfNotNull(
            immersive.o("subscriptionButton2").o("subscribeButtonRenderer"),
            immersive.o("subscriptionButton").o("subscribeButtonRenderer"),
        ).firstNotNullOfOrNull { button ->
            // Absent on a signed-out response, where the button is only ever an
            // invitation to sign in and toggling it would be a write with
            // nothing behind it.
            val subscribed = (button["subscribed"] as? JsonPrimitive)?.booleanOrNull
                ?: return@firstNotNullOfOrNull null
            val channelId = button.s("channelId")
                ?: button.a("serviceEndpoints")?.firstNotNullOfOrNull { endpoint ->
                    (endpoint.o("subscribeEndpoint").a("channelIds")?.firstOrNull()
                        as? JsonPrimitive)?.contentOrNull
                }
                ?: return@firstNotNullOfOrNull null
            SubscriptionState(channelId = channelId, subscribed = subscribed)
        }
    }

    /**
     * "1.2M subscribers" off the artist header's subscribe button — YouTube
     * ships two shapes of it depending on how the page was served, and the
     * button itself carries the count under one of three different keys
     * across those shapes.
     */
    private fun subscriberCount(header: JsonElement?): String? {
        val immersive = header.o("musicImmersiveHeaderRenderer") ?: return null
        val button2 = immersive.o("subscriptionButton2").o("subscribeButtonRenderer")
        val button1 = immersive.o("subscriptionButton").o("subscribeButtonRenderer")
        return button2.o("subscriberCountWithSubscribeText").firstRunText()
            ?: button1.o("longSubscriberCountText").firstRunText()
            ?: button1.o("shortSubscriberCountText").firstRunText()
    }

    /** "3.4M monthly listeners", off the same header as [subscriberCount]. */
    private fun monthlyListeners(header: JsonElement?): String? =
        header.o("musicImmersiveHeaderRenderer").o("monthlyListenerCount").firstRunText()

    /**
     * The name the page bills itself under. A track credited to a trio hands
     * its callers all three names at once, so the page's own header is what
     * says which of them is actually open.
     */
    private fun artistName(header: JsonElement?): String? {
        val renderer = header.o("musicImmersiveHeaderRenderer")
            ?: header.o("musicVisualHeaderRenderer")
            ?: return null
        return renderer.o("title").runs().takeIf { it.isNotBlank() }
    }

    /**
     * The artist's own picture, off whichever header shape came back — the
     * immersive header serves it as `thumbnail`, the visual header as
     * `foregroundThumbnail` over a banner. Callers that arrive from a track
     * only know that track's cover art, so this is what a page is meant to
     * show instead.
     */
    private fun artistThumbnail(header: JsonElement?): String? {
        if (header == null) return null
        val immersive = header.o("musicImmersiveHeaderRenderer")
        val visual = header.o("musicVisualHeaderRenderer")
        val renderer = (
            immersive.o("thumbnail")
                ?: visual.o("foregroundThumbnail")
                ?: visual.o("thumbnail")
            ).o("musicThumbnailRenderer")
            // Header shapes drift; fall back to the first image anywhere under
            // the header rather than to the caller's album art.
            ?: collectRenderers(header, "musicThumbnailRenderer").firstOrNull()
        return renderer.o("thumbnail").a("thumbnails").best()
    }

    // ---- Generic / robust ---------------------------------------------------

    /**
     * Walks the whole response collecting any `musicResponsiveListItemRenderer`
     * that carries a videoId. Layout-agnostic, so it survives the differences
     * between playlist, album, library and history pages.
     *
     * A podcast page's episodes are a different renderer altogether — see
     * [parseMultiRowListItem] — and are credited to [show], since they don't
     * name it themselves; see [podcastShow].
     */
    fun collectSongsDeep(root: JsonElement, show: String? = null): List<Song> {
        val out = LinkedHashMap<String, Song>()
        // A release's own rows are credited by its header, not one by one.
        val pageCredit = pageCredit(root)
        fun walk(node: JsonElement) {
            when (node) {
                is JsonObject -> {
                    node["musicResponsiveListItemRenderer"]?.let { renderer ->
                        parseResponsiveListItem(renderer as? JsonObject, pageCredit)
                            ?.let { out[it.videoId] = it }
                    }
                    node["musicMultiRowListItemRenderer"]?.let { renderer ->
                        parseMultiRowListItem(renderer as? JsonObject, show)
                            ?.let { out[it.videoId] = it }
                    }
                    node.values.forEach(::walk)
                }
                is JsonArray -> node.forEach(::walk)
                else -> Unit
            }
        }
        walk(root)
        return out.values.toList()
    }

    /**
     * The show a podcast page lists episodes for, off its own header — or null
     * on a page that lists no episodes.
     *
     * A show names itself once, at the top of its first response. Its episode
     * rows never repeat it, and a continuation has no header at all, so
     * whoever pages through a show has to carry this from the first page to
     * [collectSongsDeep] on every page after.
     */
    fun podcastShow(root: JsonElement): String? {
        if (collectRenderers(root, "musicMultiRowListItemRenderer").isEmpty()) return null
        return parseBrowseHeader(root)?.title
    }

    /** A playlist page's own tracks, the ones YouTube suggests adding, and the token for the rest. */
    data class PlaylistShelfPage(val songs: List<Song>, val suggested: List<Song>, val continuation: String?)

    /**
     * A playlist page's own track list, scoped rather than walked — plus
     * whatever YouTube offers alongside it to round the playlist out.
     *
     * A playlist the account owns can carry a "Suggestions" shelf below the
     * list actually built by hand — even a two-song playlist's own shelf
     * comes back with a continuation token that, followed, serves it rather
     * than running dry. That continuation is not another
     * `musicPlaylistShelfContinuation` page, though: it lands as a plain
     * `sectionListContinuation` carrying a `musicShelfRenderer` titled
     * "Suggestions", structurally unrelated to the shelf the real tracks
     * came from. Scoping only to the playlist shelf itself — as an earlier
     * version of this function did — reads that continuation as belonging
     * to nothing and drops it, suggestions included. So the scope here is
     * the whole secondary column (or, for a continuation response, the
     * whole `continuationContents`), and what tells a suggested row from a
     * real one is `playlistItemData` — present on every row either way, but
     * only a row actually in the playlist carries a `playlistSetVideoId`
     * inside it, the id "remove from playlist" needs. [collectSongsDeep]
     * has no notion of any of this, so a plain walk reads suggestions as
     * songs the user added. Returns null off a page with nothing
     * playlist-shaped in scope (an album, say), so callers fall back to the
     * generic walk.
     */
    fun parsePlaylistShelf(root: JsonElement): PlaylistShelfPage? {
        val scope: JsonElement = root.o("continuationContents")
            ?: root.o("contents").o("twoColumnBrowseResultsRenderer").o("secondaryContents")
            ?: return null
        val playlistScope = scope.o("musicPlaylistShelfContinuation")
            ?: collectRenderers(scope, "musicPlaylistShelfRenderer").firstOrNull()
        val suggestionShelves = collectRenderers(scope, "musicShelfRenderer")
            .filter { it.o("title").runs() == "Suggestions" }
        if (playlistScope == null && suggestionShelves.isEmpty()) return null

        val pageCredit = pageCredit(root)
        val songs = playlistScope?.let { playlist ->
            collectRenderers(playlist, "musicResponsiveListItemRenderer")
                .mapNotNull { parseResponsiveListItem(it, pageCredit) }
                .distinctBy { it.videoId }
        }.orEmpty()
        val knownSongs = songs.mapTo(HashSet()) { it.videoId }
        val suggested = suggestionShelves
            .flatMap { collectRenderers(it, "musicResponsiveListItemRenderer") }
            .mapNotNull { parseResponsiveListItem(it, pageCredit) }
            .filterNot { it.videoId in knownSongs }
            .distinctBy { it.videoId }
        // The "Suggestions" shelf's own continuation reloads it with a fresh
        // batch rather than paging it (see its "Refresh" button, wired to a
        // `reloadContinuationData` token). Only the playlist shelf's own
        // continuation means more real tracks.
        val token = playlistScope?.let { continuationToken(it) }
        return PlaylistShelfPage(songs, suggested, token)
    }

    /** One page of saved library cards, plus the token for the next page. */
    data class LibraryItemPage(val items: List<ShelfItem>, val continuation: String?)

    /**
     * The cards on a library feed — saved playlists, albums, artists, podcasts.
     *
     * Library pages remember whether the account last used the grid or the list
     * view, and serve `musicTwoRowItemRenderer` cards for one and
     * `musicResponsiveListItemRenderer` rows for the other, so both are read.
     */
    fun parseLibraryItems(root: JsonElement): List<ShelfItem> = parseLibraryItemPage(root).items

    fun parseLibraryItemPage(root: JsonElement): LibraryItemPage {
        val out = LinkedHashMap<String, ShelfItem>()
        collectRenderers(root, "musicTwoRowItemRenderer").forEach { renderer ->
            val item = parseTwoRowItem(renderer) ?: return@forEach
            item.browseId?.let { out.putIfAbsent(it, item) }
        }
        collectRenderers(root, "musicResponsiveListItemRenderer").forEach { renderer ->
            val item = parseBrowseItem(renderer) ?: return@forEach
            out.putIfAbsent(
                item.browseId,
                ShelfItem(item.title, item.subtitle, item.thumbnailUrl, null, item.browseId),
            )
        }
        return LibraryItemPage(out.values.toList(), continuationToken(root))
    }

    /**
     * Token for the next page of a paged response, or null once it has run out.
     *
     * Two token formats are in circulation. The older one:
     *   continuationItemRenderer → continuationEndpoint → continuationCommand → token
     *
     * The newer one, where YouTube wraps the command in a commandExecutorCommand
     * alongside a playlist-voting popup command:
     *   continuationItemRenderer → continuationEndpoint → commandExecutorCommand
     *     → commands[n] → continuationCommand → token
     *
     * Both the modern `continuationItemRenderer` and the older `continuations`
     * array are also in circulation at the same time.
     *
     * Only the first renderer's endpoint is read, at exactly those two depths.
     * A page with several shelves can carry several renderers, and a token
     * found anywhere deeper may page a different shelf than the one asked for.
     */
    fun continuationToken(root: JsonElement): String? {
        val endpoint = collectRenderers(root, "continuationItemRenderer").firstOrNull()
            .o("continuationEndpoint")
        (endpoint.o("continuationCommand")
            ?: endpoint.o("commandExecutorCommand").a("commands")
                ?.firstNotNullOfOrNull { it.o("continuationCommand") })
            .s("token")
            ?.let { return it }
        return collectRenderers(root, "nextContinuationData").firstOrNull().s("continuation")
    }

    // ---- Renderers ----------------------------------------------------------

    /**
     * One track row. [fallback] is what the page it came from is billed to —
     * see [pageCredit] — and is used only where the row itself says nothing.
     */
    private fun parseResponsiveListItem(
        renderer: JsonObject?,
        fallback: Credits = Credits(),
    ): Song? {
        if (renderer == null) return null
        val videoId = renderer.o("playlistItemData").s("videoId")
            ?: renderer.o("overlay")
                .o("musicItemThumbnailOverlayRenderer").o("content")
                .o("musicPlayButtonRenderer").o("playNavigationEndpoint")
                .o("watchEndpoint").s("videoId")
            ?: return null

        if (renderer.isPrivateUpload()) UploadedTracks.mark(videoId)

        val columns = renderer.a("flexColumns").orEmpty()
        val title = columns.getOrNull(0)
            .o("musicResponsiveListItemFlexColumnRenderer").o("text").runs()
        if (title.isBlank()) return null

        val subtitleRuns = columns.getOrNull(1)
            .o("musicResponsiveListItemFlexColumnRenderer").o("text").a("runs").orEmpty()
        val subtitle = subtitleRuns.joinToString("") { it.s("text").orEmpty() }
        val parts = subtitle.split(" • ").filter { it.isNotBlank() }
        // A search row states its runtime in the subtitle; an album's own rows
        // do not — the release is billed once in the header and the per-track
        // duration sits in a `fixedColumns` entry off to the right instead.
        // Nothing here read that column, so every track parsed off an album page
        // came back with a null duration, and two things downstream quietly got
        // worse for it: [LyricsTag.forTrack] fell back to matching on title and
        // artist alone against providers that key on runtime, and
        // [TrackMatcher] lost the one check that separates the album cut from
        // the extended mix sitting beside it in a source's search results.
        val duration = parts.lastOrNull()?.takeIf { it.matches(DURATION) }
            ?: renderer.a("fixedColumns").orEmpty().firstNotNullOfOrNull { column ->
                column.o("musicResponsiveListItemFixedColumnRenderer")
                    .o("text").runs().takeIf { it.matches(DURATION) }
            }
        // On the "All" tab the first segment is the row type ("Song", "Video"),
        // not the artist — skip those so the subtitle reads like a credit.
        val rowType = parts.firstOrNull { it.lowercase(Locale.ROOT) in TYPE_WORDS }?.lowercase(Locale.ROOT)
        // A track row on an album lists its play count where a search row
        // lists the artist, so a segment that reads as a tally is no credit.
        val artist = parts.firstOrNull {
            !it.matches(DURATION) && it.lowercase(Locale.ROOT) !in TYPE_WORDS && !it.matches(TALLY)
        }

        // The artist/album names in the subtitle carry browse endpoints; pull
        // them out so the long-press menu can open those pages.
        val credits = creditsOf(
            columns.flatMap {
                it.o("musicResponsiveListItemFlexColumnRenderer").o("text").a("runs").orEmpty()
            },
        )
        val creditedArtists = artistNamesFromRuns(subtitleRuns)
        // A podcast episode is billed to its show — "Episode • Sep 1 • Huberman
        // Lab" — and the show links to a podcast page, not an artist, so
        // neither credit reader above finds it and the date stood in instead.
        val episode = rowType == "episode" || renderer.isPodcastEpisode()
        val show = if (episode) showNameFromRuns(subtitleRuns) else null

        val thumbnails = renderer.o("thumbnail").o("musicThumbnailRenderer")
            .o("thumbnail").a("thumbnails")

        return Song(
            videoId = videoId,
            title = title,
            // Preserve the whole artist segment even when only some of its
            // names link to artist pages. The "All" tab can list only
            // "Song • 4:30" instead, and an album's own rows can carry no
            // credit at all, so retain the linked and page-level fallbacks.
            artist = creditedArtists
                ?: credits.artistName?.takeIf { it.isNotBlank() }
                ?: show
                ?: artist
                ?: fallback.artistName
                ?: "Unknown artist",
            thumbnailUrl = thumbnails.best(),
            durationText = duration,
            artistId = credits.artistId ?: fallback.artistId,
            artists = completeArtistCredits(artist.orEmpty(), credits.artists.ifEmpty { fallback.artists }),
            albumId = credits.albumId ?: fallback.albumId,
            albumName = credits.albumName ?: fallback.albumName,
            // Only playlist rows carry one; on an album or a search hit this
            // is simply absent, which is what makes "remove from playlist"
            // offer itself exactly where it means something.
            setVideoId = renderer.o("playlistItemData").s("playlistSetVideoId"),
            // The row type word is the clean signal when present ("All" tab);
            // otherwise a music-video upload gives itself away with widescreen
            // art where a catalogue track has square album cover art. Not an
            // episode, whose art is a widescreen still too: it is listened to,
            // and a "video" is dropped from the All tab's results.
            isVideo = !episode && (rowType == "video" || thumbnails.isNotSquare()),
            isExplicit = renderer.hasExplicitBadge(),
            // Extract the "Remove from history" feedback token from the row's menu, if present.
            feedbackToken = extractFeedbackToken(renderer),
        )
    }

    /**
     * One podcast episode, as a show page lists them
     * (`musicMultiRowListItemRenderer`) — the only rows on it, so before this
     * was read a show opened onto nothing to list and nothing to play.
     *
     * Nothing about it is shaped like a track row: the id is on the row's own
     * tap, title and subtitle are plain fields rather than flex columns, and
     * the runtime is in its progress bar as "2 hr 43 min". The show is named
     * only where the row appears away from its own page (`secondTitle`, as on
     * Explore's "Popular episodes"); on the show page, [show] stands in.
     *
     * Never a video, though the art is a widescreen still: an episode is
     * listened to, and it is played from YouTube's audio like any track.
     */
    private fun parseMultiRowListItem(renderer: JsonObject?, show: String?): Song? {
        if (renderer == null) return null
        val videoId = renderer.o("onTap").o("watchEndpoint").s("videoId")
            ?: renderer.o("overlay")
                .o("musicItemThumbnailOverlayRenderer").o("content")
                .o("musicPlayButtonRenderer").o("playNavigationEndpoint")
                .o("watchEndpoint").s("videoId")
            ?: return null
        val title = renderer.o("title").runs()
        if (title.isBlank()) return null
        return Song(
            videoId = videoId,
            title = title,
            artist = renderer.o("secondTitle").runs().takeIf { it.isNotBlank() }
                ?: show
                ?: "Unknown artist",
            thumbnailUrl = renderer.o("thumbnail").o("musicThumbnailRenderer")
                .o("thumbnail").a("thumbnails").best(),
            durationText = episodeRuntime(
                renderer.o("playbackProgress").o("musicPlaybackProgressRenderer")
                    .o("durationText").runs(),
            ),
            isExplicit = renderer.hasExplicitBadge(),
        )
    }

    /**
     * "2 hr 43 min" as the "2:43:00" every other row states its runtime in,
     * which is what [com.music.bitchord.data.model.durationMillis] reads.
     * Null for anything it can't read, such as another language's units.
     */
    private fun episodeRuntime(text: String): String? {
        var seconds = 0L
        RUNTIME_PART.findAll(text).forEach { part ->
            val count = part.groupValues[1].toLong()
            seconds += when (part.groupValues[2].lowercase(Locale.ROOT).first()) {
                'h' -> count * 3_600
                'm' -> count * 60
                else -> count
            }
        }
        if (seconds == 0L) return null
        val hours = seconds / 3_600
        val minutes = seconds % 3_600 / 60
        val secs = seconds % 60
        return if (hours > 0) {
            String.format(Locale.ROOT, "%d:%02d:%02d", hours, minutes, secs)
        } else {
            String.format(Locale.ROOT, "%d:%02d", minutes, secs)
        }
    }

    /** The show an episode row's subtitle links to, by the page type that link opens. */
    private fun showNameFromRuns(runs: List<JsonElement>): String? =
        runs.firstOrNull { run ->
            run.o("navigationEndpoint").o("browseEndpoint")
                .o("browseEndpointContextSupportedConfigs")
                .o("browseEndpointContextMusicConfig").s("pageType")
                .orEmpty().contains("PODCAST_SHOW")
        }?.s("text")?.trim()?.takeIf { it.isNotBlank() }

    /**
     * The promoted result at the top of an unfiltered search is a
     * `musicCardShelfRenderer`. Unlike the rows below it, its playable id and
     * credits are placed directly on the card, so it would otherwise vanish
     * from the All tab while remaining first in the Songs tab.
     */
    private fun parseCardShelfSong(renderer: JsonObject): Song? {
        val videoId = renderer.o("onTap").o("watchEndpoint").s("videoId") ?: return null
        val title = renderer.o("title").runs()
        if (title.isBlank()) return null

        val subtitleRuns = renderer.o("subtitle").a("runs").orEmpty()
        val subtitle = subtitleRuns.joinToString("") { it.s("text").orEmpty() }
        val parts = subtitle.split(" • ").filter { it.isNotBlank() }
        val duration = parts.lastOrNull()?.takeIf { it.matches(DURATION) }
        val rowType = parts.firstOrNull { it.lowercase(Locale.ROOT) in TYPE_WORDS }
            ?.lowercase(Locale.ROOT)
        val credits = creditsOf(subtitleRuns)
        val creditedArtists = artistNamesFromRuns(subtitleRuns)
        val artist = parts.firstOrNull {
            !it.matches(DURATION) && it.lowercase(Locale.ROOT) !in TYPE_WORDS && !it.matches(TALLY)
        }
        val thumbnails = renderer.o("thumbnail").o("musicThumbnailRenderer")
            .o("thumbnail").a("thumbnails")

        return Song(
            videoId = videoId,
            title = title,
            artist = creditedArtists
                ?: credits.artistName?.takeIf { it.isNotBlank() }
                ?: artist
                ?: "Unknown artist",
            thumbnailUrl = thumbnails.best(),
            durationText = duration,
            artistId = credits.artistId,
            artists = completeArtistCredits(artist.orEmpty(), credits.artists),
            albumId = credits.albumId,
            albumName = credits.albumName,
            isVideo = rowType == "video" || thumbnails.isNotSquare(),
            isExplicit = renderer["subtitleBadges"].hasExplicitBadge(),
        )
    }

    /**
     * Who the rows inside a promoted card are by, or null if the card isn't
     * one that bills them.
     *
     * An artist card is a header with a track list under it, the same shape a
     * release page has: searching "mc stan" promotes the artist and hangs three
     * of their songs off the card, and those rows say only "Song • 3:16" —
     * the credit is on the card, stated once, so every row read on its own came
     * back as "Unknown artist". This is [pageCredit] for the one page that
     * carries a header without being a page.
     *
     * Only artist cards, which is why this reads `onTap` rather than the
     * subtitle. A song or video card's rows are *related* uploads rather than
     * its own — "Shape of You" promotes the track and lists a dance cover and a
     * choreography video under it, by other people entirely — so lending them
     * the card's credit would put the wrong name on rows that are not missing
     * one to begin with.
     */
    private fun cardShelfCredit(card: JsonObject): Credits? {
        val endpoint = card.o("onTap").o("browseEndpoint") ?: return null
        val pageType = endpoint.o("browseEndpointContextSupportedConfigs")
            .o("browseEndpointContextMusicConfig").s("pageType").orEmpty()
        if ("ARTIST" !in pageType) return null
        val name = card.o("title").runs().takeIf { it.isNotBlank() } ?: return null
        // Deliberately no album: the card says who the song is by and nothing
        // about which release it came off, and a guess there would show up as a
        // wrong "go to album" in the row's own long-press menu.
        return Credits(artistId = endpoint.s("browseId"), artistName = name)
    }

    /** Artist, album and playlist cards use the same promoted-search container as a song. */
    private fun parseCardShelfBrowse(renderer: JsonObject): BrowseItem? {
        val endpoint = renderer.o("onTap").o("browseEndpoint") ?: return null
        val browseId = endpoint.s("browseId") ?: return null
        val pageType = endpoint.o("browseEndpointContextSupportedConfigs")
            .o("browseEndpointContextMusicConfig").s("pageType").orEmpty()
        // An upload YouTube never matched to the catalogue, billed as an
        // "Episode" and opening an `MPED…` page. Signed out it is often what a
        // big song's own title promotes — "tum hi ho", "o maahi" — while the
        // real track sits in the rows below, so it doesn't get the top slot.
        // Read off the page type rather than the word, which is translated.
        if ("NON_MUSIC_AUDIO_TRACK" in pageType) return null
        val title = renderer.o("title").runs()
        if (title.isBlank()) return null
        val subtitle = renderer.o("subtitle").runs()
        if (VIDEO_WORD.containsMatchIn(title) || VIDEO_WORD.containsMatchIn(subtitle)) return null

        return BrowseItem(
            browseId = browseId,
            title = title,
            subtitle = subtitle,
            thumbnailUrl = renderer.o("thumbnail").o("musicThumbnailRenderer")
                .o("thumbnail").a("thumbnails").best(),
            type = when {
                "ALBUM" in pageType -> BrowseType.ALBUM
                "ARTIST" in pageType -> BrowseType.ARTIST
                "PLAYLIST" in pageType -> BrowseType.PLAYLIST
                else -> BrowseType.OTHER
            },
        )
    }

    /**
     * A chart row that names an artist rather than a track — "Top artists"
     * on the Charts page lists 40 of them with no song attached, so there is
     * no `videoId` for [parseResponsiveListItem] to key off and it returns
     * null for every one. Read here off the row's own `navigationEndpoint`
     * instead (the flex columns carry only the name and a subscriber count)
     * and pointed at the artist page rather than dropped.
     */
    private fun parseArtistRow(renderer: JsonObject?): ShelfItem? {
        if (renderer == null) return null
        val endpoint = renderer.o("navigationEndpoint").o("browseEndpoint")
        val pageType = endpoint.o("browseEndpointContextSupportedConfigs")
            .o("browseEndpointContextMusicConfig").s("pageType").orEmpty()
        if ("ARTIST" !in pageType) return null
        val browseId = endpoint.s("browseId") ?: return null

        val columns = renderer.a("flexColumns").orEmpty()
        val title = columns.getOrNull(0)
            .o("musicResponsiveListItemFlexColumnRenderer").o("text").runs()
        if (title.isBlank()) return null
        val subtitle = columns.getOrNull(1)
            .o("musicResponsiveListItemFlexColumnRenderer").o("text").runs()

        val thumbnails = renderer.o("thumbnail").o("musicThumbnailRenderer")
            .o("thumbnail").a("thumbnails")
        return ShelfItem(
            title = title,
            subtitle = subtitle,
            thumbnailUrl = thumbnails.best(),
            videoId = null,
            browseId = browseId,
        )
    }

    /** The artist / album pages a run list links out to, and their names. */
    private data class Credits(
        val artistId: String? = null,
        val artistName: String? = null,
        /** Every credited artist, not just the lead — see [Song.artists]. */
        val artists: List<ArtistRef> = emptyList(),
        val albumId: String? = null,
        val albumName: String? = null,
    )

    /**
     * The artist and album a run list links out to, and every credited artist.
     *
     * A byline states one navigation endpoint per artist, so a collaboration
     * arrives here as several runs rather than as one run with a longer name.
     * Taking the first and dropping the rest is what left every credit after
     * the lead unopenable: there was no id for it, and a name is not an
     * identity, so searching for one finds whoever else answers to it.
     *
     * Only the first ARTIST and ALBUM run become [artistId] and [albumId],
     * because that is what the rest of the app treats as *the* artist and *the*
     * album. Every ARTIST run is kept in [artists], in the order written.
     *
     * Every link read here is also handed to [ArtistNameIndex], because YouTube
     * is not consistent about which credited artists it links — see that class
     * for the rows that come back with one name linked and the next not.
     */
    private fun creditsOf(runs: List<JsonElement>): Credits {
        var credits = Credits()
        val artists = mutableListOf<ArtistRef>()
        runs.forEach { run ->
            val browse = run.o("navigationEndpoint").o("browseEndpoint")
            val id = browse.s("browseId") ?: return@forEach
            val pageType = browse.o("browseEndpointContextSupportedConfigs")
                .o("browseEndpointContextMusicConfig").s("pageType").orEmpty()
            if ("ARTIST" !in pageType && "ALBUM" !in pageType) return@forEach
            val name = run.s("text").orEmpty()
            if ("ARTIST" in pageType) {
                if (name.isNotBlank()) {
                    artists += ArtistRef(name = name, browseId = id)
                }
                if (credits.artistId == null) {
                    credits = credits.copy(artistId = id, artistName = name)
                }
            } else if (credits.albumId == null) {
                credits = credits.copy(albumId = id, albumName = name)
            }
        }
        ArtistNameIndex.record(artists)
        return if (artists.isEmpty()) credits else credits.copy(artists = artists)
    }

    /**
     * Every name in the artist segment, including names without a browse link.
     * YouTube alternates name and separator runs inside a bullet-delimited
     * segment, but only some names are guaranteed to carry an artist endpoint.
     */
    private fun artistNamesFromRuns(runs: List<JsonElement>): String? {
        val groups = mutableListOf<MutableList<JsonElement>>(mutableListOf())
        runs.forEach { run ->
            if (run.s("text")?.trim() == "•") {
                groups += mutableListOf<JsonElement>()
            } else {
                groups.last() += run
            }
        }
        val artistGroup = groups.firstOrNull { group ->
            group.any { run ->
                val pageType = run.o("navigationEndpoint").o("browseEndpoint")
                    .o("browseEndpointContextSupportedConfigs")
                    .o("browseEndpointContextMusicConfig").s("pageType").orEmpty()
                "ARTIST" in pageType
            }
        } ?: return null
        return artistGroup.mapIndexedNotNull { index, run ->
            if (index % 2 != 0) return@mapIndexedNotNull null
            run.s("text")?.trim()?.takeIf { it.isNotBlank() }
        }.distinct().joinToString(", ").ifBlank { null }
    }

    /**
     * Who a release page is billed to, off its own header.
     *
     * An album or single doesn't repeat the credit on every track — it says
     * "Single • Dhanda Nyoliwala" once at the top and then lists bare titles,
     * so every row read on its own comes back as "Unknown artist". The header
     * is that missing credit, and carries the artist's browse id with it, so
     * the long-press menu can still open the artist page from those rows.
     *
     * Only releases, never playlists: a playlist's header names whoever put
     * it together, which is not what its tracks are by. Playlist rows carry
     * their own credits anyway.
     */
    private fun pageCredit(root: JsonElement): Credits {
        val header = HEADER_RENDERERS.firstNotNullOfOrNull {
            collectRenderers(root, it).firstOrNull()
        } ?: return Credits()
        // The current header hangs the artist off a strapline above the title;
        // the older one packs it into the subtitle, "Album • Artist • 2024".
        val lines = HEADER_CREDIT_LINES.map { header.o(it).a("runs").orEmpty() }
        // Split per line, not across them: the strapline and the subtitle are
        // separate sentences, and running them together would weld the artist
        // onto the word that says this is a release at all.
        val parts = lines.flatMap { line ->
            line.joinToString("") { it.s("text").orEmpty() }.split(" • ", " · ").map(String::trim)
        }
        if (parts.none { it.lowercase(Locale.ROOT) in RELEASE_WORDS }) return Credits()

        val credits = creditsOf(lines.flatten())
        val creditedArtists = lines.firstNotNullOfOrNull(::artistNamesFromRuns)
        if (creditedArtists != null) return credits.copy(artistName = creditedArtists)
        // An artist YouTube has no page for is named in the same line without
        // a link to follow, leaving the name as the only thing to go on.
        val name = parts.firstOrNull {
            it.isNotBlank() && it.lowercase(Locale.ROOT) !in TYPE_WORDS && !it.matches(TALLY) &&
                !it.matches(YEAR) && !it.matches(DURATION)
        }
        return credits.copy(artistName = name)
    }

    /** How an album or playlist page bills itself, off its own header. */
    data class BrowseHeader(
        val title: String,
        /** The line under it — "Album • Artist • 2024", or a playlist's blurb. */
        val subtitle: String,
        val thumbnailUrl: String?,
    )

    /**
     * What a release or playlist page calls itself.
     *
     * Every other way into a detail page comes from a card that already carried
     * the name and the cover, so nothing used to have to ask. A YouTube Music
     * link tapped outside the app carries a browse id and nothing else — see
     * [com.music.bitchord.playback.MusicLink] — and a page with a blank title
     * over a track list reads as the app having half-loaded.
     */
    fun parseBrowseHeader(root: JsonElement): BrowseHeader? {
        val header = HEADER_RENDERERS.firstNotNullOfOrNull {
            collectRenderers(root, it).firstOrNull()
        } ?: return null
        val title = header.o("title").runs()
        if (title.isBlank()) return null
        // Current headers split the artist and release details across these two
        // lines: the strapline has the artist, while the subtitle holds
        // "Album • 2024". Keep both; taking only the first silently loses the
        // release year on album pages. Older headers put everything in one of
        // the two lines, which is covered as well.
        val subtitle = HEADER_CREDIT_LINES
            .map { header.o(it).runs() }
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString(" • ")
        return BrowseHeader(
            title = title,
            subtitle = subtitle,
            // Header shapes drift — a cropped square here, a plain thumbnail
            // there — so the first image under the header is the cover.
            thumbnailUrl = collectRenderers(header, "musicThumbnailRenderer").firstOrNull()
                .o("thumbnail").a("thumbnails").best(),
        )
    }

    /**
     * The playlist that contains a catalogue album's complete track listing.
     *
     * Album browse pages can expose only a short preview even though their
     * header reports the release's full song count. The play action points at
     * the playlist that backs the release, which is the authoritative listing.
     * Keep the search scoped to the page header: recommendation shelves contain
     * play actions for other releases too.
     */
    fun parseAlbumPlaylistId(root: JsonElement): String? {
        val header = HEADER_RENDERERS.firstNotNullOfOrNull {
            collectRenderers(root, it).firstOrNull()
        }
        if (header != null) {
            collectRenderers(header, "musicPlayButtonRenderer")
                .firstNotNullOfOrNull { it.playlistIdFromPlayAction() }
                ?.let { return it }
            collectRenderers(header, "buttonRenderer")
                .firstNotNullOfOrNull { it.playlistIdFromPlayAction() }
                ?.let { return it }
        }

        // Some album layouts omit the header play button but repeat the same
        // playlist in the canonical album URL.
        val canonical = root.o("microformat").o("microformatDataRenderer").s("urlCanonical")
            ?: return null
        return canonical.substringAfter("list=", missingDelimiterValue = "")
            .substringBefore('&')
            .takeIf { it.isNotBlank() }
    }

    private fun JsonElement.playlistIdFromPlayAction(): String? {
        val endpoint = o("playNavigationEndpoint")
            ?: o("navigationEndpoint")
            ?: this
        return endpoint.o("watchPlaylistEndpoint").s("playlistId")
            ?: endpoint.o("watchEndpoint").s("playlistId")
    }

    /**
     * The editorial blurb YouTube Music writes for a release or an artist —
     * "About the album" / "About the artist" on the web player.
     *
     * It arrives as its own shelf (`musicDescriptionShelfRenderer`) on a
     * current-layout page, but the field also turns up directly on the
     * header itself on some responses, so both are tried. Absent from a
     * playlist page — YouTube writes these for its own catalogue, not for
     * something a user put together — which is why callers only surface it
     * for [com.music.bitchord.data.model.BrowseType.ALBUM] and
     * [com.music.bitchord.data.model.BrowseType.ARTIST].
     */
    fun parseDescription(root: JsonElement): String? {
        val shelf = collectRenderers(root, "musicDescriptionShelfRenderer")
            .firstOrNull()?.o("description").runs()
        if (shelf.isNotBlank()) return shelf
        val onHeader = (HEADER_RENDERERS + "musicImmersiveHeaderRenderer")
            .firstNotNullOfOrNull { name ->
                collectRenderers(root, name).firstOrNull()
                    ?.o("description").runs().takeIf { it.isNotBlank() }
            }
        return onHeader
    }

    /**
     * The account header buried in the `account_menu` popup. Not every client
     * gets an `email` back — some return only the @handle — so whichever is
     * present is used as the secondary line.
     */
    fun parseAccount(response: JsonElement): Account? {
        val header = collectRenderers(response, "activeAccountHeaderRenderer").firstOrNull()
            ?: return null
        val name = header.o("accountName").runs()
        if (name.isBlank()) return null
        val email = header.o("email").runs()
            .ifBlank { header.o("email").s("simpleText").orEmpty() }
            .ifBlank { header.o("channelHandle").runs() }
        return Account(
            name = name,
            email = email,
            thumbnailUrl = header.o("accountPhoto").a("thumbnails").best(),
        )
    }

    /**
     * The channels a switcher response offers, in the order YouTube lists them.
     *
     * Read by scanning for `accountItem` rather than by walking a fixed path:
     * the two endpoints that produce this list ([Innertube.accountsList] and
     * [Innertube.accountSwitcher]) wrap the same item renderer in different
     * envelopes, and the wrapper is not the part worth agreeing on.
     *
     * The two tokens are likewise found by name anywhere inside the item. They
     * arrive as a list of single-key objects under `supportedTokens`, in no
     * promised order and alongside tokens meant for other purposes, so a
     * positional read of that list would be a guess about a structure Google
     * never said was ordered.
     *
     * An entry with neither token is dropped. There would be nothing to send
     * for it, and offering a channel that silently keeps the current one is
     * worse than not listing it.
     */
    fun parseAccountChannels(root: JsonElement): List<AccountChannel> =
        collectRenderers(root, "accountItem").mapNotNull { item ->
            val name = item.o("accountName").runs()
                .ifBlank { item.o("accountName").s("simpleText").orEmpty() }
            if (name.isBlank()) return@mapNotNull null
            val pageId = item.findString("pageId")
            val dataSyncId = normalizeDataSyncId(item.findString("datasyncIdToken"))
            if (pageId == null && dataSyncId == null) return@mapNotNull null
            AccountChannel(
                name = name,
                subtitle = item.o("channelHandle").runs()
                    .ifBlank { item.o("channelHandle").s("simpleText").orEmpty() }
                    .ifBlank { item.o("accountByline").runs() }
                    .ifBlank { item.o("accountByline").s("simpleText").orEmpty() },
                thumbnailUrl = item.o("accountPhoto").a("thumbnails").best(),
                pageId = pageId,
                dataSyncId = dataSyncId,
                activeOnWeb = (item["isSelected"] as? JsonPrimitive)?.content == "true",
            )
        }.distinctBy { it.key }

    /**
     * How many rows of a watch queue YouTube paired with their other version
     * (a `playlistPanelVideoWrapperRenderer`), and how many of those pairs
     * offered an audio track — for the debug log, since signed-out responses
     * carry no pairs at all.
     */
    fun watchQueuePairs(root: JsonElement): Pair<Int, Int> {
        val wrappers = collectRenderers(root, "playlistPanelVideoWrapperRenderer")
        return wrappers.size to wrappers.count { wrapper -> wrapperRenderers(wrapper).any { it.isAudioTrack() } }
    }

    private fun wrapperRenderers(wrapper: JsonObject): List<JsonObject> =
        listOfNotNull(wrapper.o("primaryRenderer").o("playlistPanelVideoRenderer")) +
            wrapper.a("counterpart").orEmpty().mapNotNull { it.o("counterpartRenderer").o("playlistPanelVideoRenderer") }

    /** A catalogue song (ATV), as opposed to a music video upload. */
    private fun JsonObject.isAudioTrack(): Boolean = musicVideoType() == MUSIC_VIDEO_TYPE_ATV

    private fun JsonObject.musicVideoType(): String? =
        o("navigationEndpoint").o("watchEndpoint").o("watchEndpointMusicSupportedConfigs")
            .o("watchEndpointMusicConfig").s("musicVideoType")

    private const val MUSIC_VIDEO_TYPE_ATV = "MUSIC_VIDEO_TYPE_ATV"

    /**
     * Tracks of a watch queue (`next` response) — the AutoPlay radio mix.
     *
     * With [preferAudio], a row YouTube pairs with its other version — an
     * official video and the song it's a video of, the Song/Video switch in
     * YouTube Music — comes back as the song, so it plays as audio straight
     * away instead of being matched to its audio version afterwards. Without
     * it, both halves of a pair are read, as they always have been.
     *
     * [preferVideo] is the other way round: a pair comes back as its music
     * video, for a queue that plays on from a video.
     */
    fun parseWatchQueue(root: JsonElement, preferAudio: Boolean = false, preferVideo: Boolean = false): List<Song> {
        val out = LinkedHashMap<String, Song>()
        // Each pair stands in the queue as one row: the audio half where
        // there is one, and the other half dropped.
        val replacements = HashMap<String, JsonObject>()
        val dropped = HashSet<String>()
        if (preferAudio || preferVideo) {
            collectRenderers(root, "playlistPanelVideoWrapperRenderer").forEach { wrapper ->
                val halves = wrapperRenderers(wrapper)
                val primary = halves.firstOrNull() ?: return@forEach
                val audio = halves.firstOrNull { if (preferVideo) !it.isAudioTrack() else it.isAudioTrack() }
                    ?: return@forEach
                val primaryId = primary.s("videoId") ?: return@forEach
                replacements[primaryId] = audio
                halves.filter { it !== primary }.mapNotNullTo(dropped) { it.s("videoId") }
            }
        }
        collectRenderers(root, "playlistPanelVideoRenderer").forEach { found ->
            val foundId = found.s("videoId") ?: return@forEach
            if (foundId in dropped) return@forEach
            val song = panelSong(replacements[foundId] ?: found) ?: return@forEach
            out[song.videoId] = song
        }
        return out.values.toList()
    }

    /** One row of a watch queue as a [Song], or null for a row with no id or title. */
    private fun panelSong(renderer: JsonObject): Song? {
        val videoId = renderer.s("videoId") ?: return null
        val title = renderer.o("title").runs()
        if (title.isBlank()) return null
        // The byline packs artist, views and likes into one run list; only
        // the leading runs before the first bullet are the credit.
        val bylineRuns = renderer.o("longBylineText").a("runs").orEmpty()
        val byline = bylineRuns.map { it.s("text").orEmpty() }
        val artist = byline.takeWhile { !it.contains("•") }.joinToString("").trim()
        // Those same runs link out to the artist and album pages, which is
        // how a track started from the queue knows where it came from.
        val credits = creditsOf(bylineRuns)
        return Song(
            videoId = videoId,
            title = title,
            artist = artist,
            thumbnailUrl = renderer.o("thumbnail").a("thumbnails").best(),
            durationText = renderer.o("lengthText").runs().takeIf { it.isNotBlank() },
            artistId = credits.artistId,
            artists = completeArtistCredits(artist.orEmpty(), credits.artists),
            albumId = credits.albumId,
            albumName = credits.albumName,
            // A catalogue track is credited "Artist • Album • Year"; the
            // matching music video is "Artist • 417M views • 2.4M likes".
            isVideo = byline.any { it.contains("views", ignoreCase = true) },
            isExplicit = renderer.hasExplicitBadge(),
        )
    }

    /**
     * The other version of [videoId] as YouTube Music itself pairs it — the
     * song for an official video when [wantAudio], the video for a song
     * otherwise — with the time map its Song/Video switch uses, when the
     * response carries one. Read off a `next` response for [videoId].
     *
     * Null when YouTube offers no pair, which is every signed-out response and
     * any upload that is not an official video. The caller falls back to a
     * search; nothing here guesses.
     *
     * The pair can come back either way round: the track asked about as the
     * row's primary with the other version as its counterpart, or the other
     * way, in which case the time map is read backwards.
     */
    fun parseVersionPair(root: JsonElement, videoId: String, wantAudio: Boolean): VersionPair? {
        // A row whose type YouTube left out is still the other half of a pair;
        // only a row that says it is the wrong kind is turned away.
        fun JsonObject.fits(): Boolean = musicVideoType()?.let { (it == MUSIC_VIDEO_TYPE_ATV) == wantAudio } ?: true

        collectRenderers(root, "playlistPanelVideoWrapperRenderer").forEach { wrapper ->
            val primary = wrapper.o("primaryRenderer").o("playlistPanelVideoRenderer") ?: return@forEach
            val counterparts = wrapper.a("counterpart").orEmpty().filterIsInstance<JsonObject>()
            fun JsonObject.renderer(): JsonObject? = o("counterpartRenderer").o("playlistPanelVideoRenderer")

            if (primary.s("videoId") == videoId) {
                val match = counterparts.firstOrNull { it.renderer()?.fits() == true } ?: return@forEach
                val song = panelSong(match.renderer() ?: return@forEach) ?: return@forEach
                return VersionPair(song.copy(isVideo = !wantAudio), timeMapOf(match))
            }
            val asCounterpart = counterparts.firstOrNull { it.renderer().s("videoId") == videoId } ?: return@forEach
            if (!primary.fits()) return@forEach
            val song = panelSong(primary) ?: return@forEach
            return VersionPair(song.copy(isVideo = !wantAudio), timeMapOf(asCounterpart)?.inverted())
        }
        return null
    }

    /**
     * A counterpart's `segmentMap`: primary-side start, counterpart-side start
     * and length of every stretch the two share. The numbers are int64s, which
     * protobuf's JSON mapping writes as strings, so both forms are read.
     */
    private fun timeMapOf(counterpart: JsonObject): VersionTimeMap? {
        val segments = counterpart.o("segmentMap").a("segment").orEmpty().mapNotNull { segment ->
            val from = segment.s("primaryVideoStartTimeMilliseconds")?.toLongOrNull() ?: return@mapNotNull null
            val to = segment.s("counterpartVideoStartTimeMilliseconds")?.toLongOrNull() ?: return@mapNotNull null
            val length = segment.s("durationMilliseconds")?.toLongOrNull()?.takeIf { it > 0 }
                ?: return@mapNotNull null
            VersionTimeMap.Segment(fromStartMs = from, toStartMs = to, durationMs = length)
        }
        return segments.takeIf { it.isNotEmpty() }?.let(::VersionTimeMap)
    }

    /**
     * The "Remove from history" feedback token on a history row's menu, or
     * null. The same plain menu items also carry other feedback actions —
     * "Don't recommend this", for one — so only the item wearing the DELETE
     * icon is taken; sending a stranger's token would quietly do something
     * else to the account.
     */
    private fun extractFeedbackToken(renderer: JsonObject): String? =
        renderer.o("menu")
            ?.o("menuRenderer")
            ?.a("items")
            ?.firstNotNullOfOrNull { item ->
                val service = item.o("menuServiceItemRenderer") ?: return@firstNotNullOfOrNull null
                if (service.o("icon")?.s("iconType") != "DELETE") return@firstNotNullOfOrNull null
                service.o("serviceEndpoint")?.o("feedbackEndpoint")?.s("feedbackToken")
            }

    /**
     * The account's own state for one track, read off the watch queue's row
     * menu: the thumbs rating, and the tokens that toggle library membership.
     *
     * Read from `next` rather than from anywhere cheaper because there is
     * nowhere cheaper — no endpoint answers "is this liked" on its own, and
     * library membership is only ever expressed as a pair of opaque tokens
     * attached to a rendered row. The queue's own entry for the track carries
     * both, so one call answers the whole menu.
     *
     * Scoped to [videoId]'s row: a watch queue is a list, and reading the
     * first `likeButtonRenderer` in the response would answer for whichever
     * track happened to be rendered first.
     */
    fun parseSongMenu(root: JsonElement, videoId: String): SongMenu? {
        val row = collectRenderers(root, "playlistPanelVideoRenderer")
            .firstOrNull { it.s("videoId") == videoId }
            ?: return null

        // Null, not INDIFFERENT, for anything this row doesn't actually say —
        // see [SongMenu.likeStatus]. A missing like button and a stated
        // "no rating" are different answers and must not collapse into one.
        val likeStatus = when (
            collectRenderers(row, "likeButtonRenderer").firstOrNull().s("likeStatus")
        ) {
            "LIKE" -> LikeStatus.LIKE
            "DISLIKE" -> LikeStatus.DISLIKE
            "INDIFFERENT" -> LikeStatus.INDIFFERENT
            else -> null
        }

        // A row's menu carries several toggles that all hang a feedback token
        // off the same endpoint — "Don't recommend this", "Remove from
        // history". Only the one wearing a library icon is this one, and
        // taking the first token that turned up meant reading a stranger's
        // state: its default icon isn't LIBRARY_ADD, so every song it matched
        // claimed to already be in the library.
        val toggle = collectRenderers(row, "toggleMenuServiceItemRenderer")
            .firstOrNull { it.feedbackToken("defaultServiceEndpoint") != null && it.isLibraryToggle }
        // A toggle states the action available *now* as its default and the
        // way back as its toggled half, so which icon leads also says whether
        // the track is in the library already.
        val defaultAdds = toggle.o("defaultIcon").s("iconType") == "LIBRARY_ADD"
        val defaultToken = toggle.feedbackToken("defaultServiceEndpoint")
        val toggledToken = toggle.feedbackToken("toggledServiceEndpoint")

        return SongMenu(
            likeStatus = likeStatus,
            inLibrary = toggle != null && !defaultAdds,
            addToLibraryToken = if (defaultAdds) defaultToken else toggledToken,
            removeFromLibraryToken = if (defaultAdds) toggledToken else defaultToken,
        )
    }

    private fun JsonElement?.feedbackToken(endpoint: String): String? =
        this.o(endpoint).o("feedbackEndpoint").s("feedbackToken")

    /**
     * Whether a toggle menu item is the library one, told by its icons rather
     * than by its label — the label is localised, the icon type never is.
     */
    private val JsonElement?.isLibraryToggle: Boolean
        get() = LIBRARY_ICONS.any {
            o("defaultIcon").s("iconType") == it || o("toggledIcon").s("iconType") == it
        }

    private val LIBRARY_ICONS = setOf("LIBRARY_ADD", "LIBRARY_REMOVE", "LIBRARY_SAVED")

    /**
     * Whether the album or playlist a browse response describes is in the
     * library, and the id that would change that — see [LibraryState].
     *
     * Both come off the page header, and both have to. A release's save control
     * is a [toggleButtonRenderer][isSaveToggle] wearing YouTube's bookmark
     * icons, *not* a like button: every track row on the page carries a
     * `likeButtonRenderer` aimed at its own `videoId` and the release carries
     * none at all, so reading a like button here answers for a track. Which is
     * how the first cut of this came back empty on every page — thirteen like
     * buttons on an album, every one of them a row's.
     *
     * The id is read from the header's *play* button, because it isn't the
     * browse id the page was fetched with: an `MPREb…` album is backed by an
     * `OLAK5uy_…` playlist, which the button names as a `watchPlaylistEndpoint`,
     * while a playlist page names its own raw id as a `watchEndpoint`. One of
     * the two answers for either kind of page.
     *
     * Scoped to the header rather than walked for, which matters more here than
     * it looks: an album page's "more from this artist" carousel is full of
     * *other* releases' playlist ids — a dozen of them, ahead of the header in
     * document order — so a page-wide walk would quietly save the wrong record.
     *
     * Null when the header has no save button to read: a continuation, a local
     * page, an auto-playlist, or a release YouTube marks unsaveable.
     */
    fun parseLibraryState(root: JsonElement): LibraryState? {
        val buttons = collectRenderers(root, "musicResponsiveHeaderRenderer")
            .firstOrNull()
            .a("buttons")
            .orEmpty()
        val save = buttons.firstNotNullOfOrNull { it.o("toggleButtonRenderer")?.takeIf { b -> b.isSaveToggle } }
            ?: return null
        if (save.s("isDisabled") == "true") return null
        // A play button states the release as a playlist, which is the one
        // thing on the page that names what saving would act on.
        val play = buttons.firstNotNullOfOrNull { it.o("musicPlayButtonRenderer").o("playNavigationEndpoint") }
        return LibraryState(
            playlistId = play.o("watchPlaylistEndpoint").s("playlistId")
                ?: play.o("watchEndpoint").s("playlistId")
                ?: return null,
            // The toggle carries the answer directly, rather than the
            // which-icon-leads reading a menu toggle needs: a button that is
            // *shown* toggled is one whose release is already saved.
            saved = save.s("isToggled") == "true",
        )
    }

    /**
     * Whether a header toggle is the save-to-library one rather than the
     * description's expander, told by its icons for the same reason
     * [isLibraryToggle] is: the label is localised, the icon type never is.
     *
     * Bookmarks, not the `LIBRARY_*` icons a track's menu uses — YouTube draws
     * the two actions differently even though they land in the same library.
     */
    private val JsonElement?.isSaveToggle: Boolean
        get() = o("defaultIcon").s("iconType") == "BOOKMARK_BORDER" ||
            o("toggledIcon").s("iconType") == "BOOKMARK"

    /**
     * Whether a playlist page is one the account *made*, rather than one it
     * merely saved — null when the response doesn't say either way.
     *
     * The library feed can't answer this. `FEmusic_liked_playlists` lists a
     * stranger's playlist this account saved in exactly the same shape as one
     * this account created (see [parseUserPlaylists]), which is how Rename and
     * Delete came to be offered on someone else's playlist. The page can
     * answer, and does so three ways over:
     *
     *  - An own playlist's header comes wrapped in
     *    `musicEditablePlaylistDetailHeaderRenderer` — YouTube's own words for
     *    "this belongs to whoever is asking".
     *  - Its header menu carries the Edit and Delete rows, read by icon rather
     *    than by label for the same reason [isSaveToggle] is.
     *  - Its header carries no save bookmark, and a saved playlist's always
     *    does: there is nothing to save a playlist already yours *into*. So a
     *    playlist header without one is this account's.
     *
     * Any one of the three is enough, because the two mistakes cost different
     * amounts. Reading "saved" as "own" puts a Delete button on a playlist the
     * account cannot delete; reading "own" as "saved" takes Rename and Delete
     * off the user's own playlist, which is a feature quietly vanishing. Three
     * readings rather than one so a layout change can only ever cause the
     * first, which the edit endpoint would refuse anyway.
     *
     * Only meaningful for a `VL…` playlist page — an album has a save bookmark
     * and no owner in this sense at all, and a continuation has no header.
     */
    fun parsePlaylistOwned(root: JsonElement): Boolean? {
        if (collectRenderers(root, "musicEditablePlaylistDetailHeaderRenderer").isNotEmpty()) {
            return true
        }
        // Scoped to the header, not walked for: every track row on the page
        // carries its own menu, and a row's "Remove from playlist" would
        // answer for the row rather than for the playlist.
        val header = collectRenderers(root, "musicResponsiveHeaderRenderer").firstOrNull()
            ?: return null
        if (collectRenderers(header, "menuNavigationItemRenderer")
                .any { it.o("icon").s("iconType") in OWNER_ICONS }
        ) {
            return true
        }
        return header.a("buttons").orEmpty().none { it.o("toggleButtonRenderer").isSaveToggle }
    }

    /** Header menu icons only the playlist's owner is offered. */
    private val OWNER_ICONS = setOf("DELETE", "EDIT")

    /**
     * The playlists the account can be asked to add a track to.
     *
     * `FEmusic_liked_playlists` also carries the "New playlist" tile (no
     * browse id, so it never survives [parseLibraryItems]), the Liked Music
     * auto-playlist and YouTube's own generated mixes — none of which take an
     * edit.
     *
     * Filtered by exclusion rather than by requiring a `PL` prefix. Playlist
     * ids are not as regular as they look, and a list that quietly drops the
     * user's own playlist is worse than one that offers a playlist the edit
     * endpoint then refuses — which it reports, and which the picker surfaces.
     *
     * Whether a playlist is *owned* rather than merely saved isn't stated on
     * this feed at all, so it isn't decided here: this stays the permissive
     * list the picker wants, and [parsePlaylistOwned] is what rules a saved
     * playlist out of being renamed or deleted.
     */
    fun parseUserPlaylists(root: JsonElement): List<UserPlaylist> =
        parseUserPlaylists(parseLibraryItems(root))

    fun parseUserPlaylists(items: List<ShelfItem>): List<UserPlaylist> =
        items.mapNotNull { item ->
            val browseId = item.browseId ?: return@mapNotNull null
            if (!browseId.startsWith("VL")) return@mapNotNull null
            if (NOT_EDITABLE.any { browseId.startsWith("VL$it") }) return@mapNotNull null
            UserPlaylist(
                playlistId = browseId.removePrefix("VL"),
                title = item.title,
                subtitle = item.subtitle,
                thumbnailUrl = item.thumbnailUrl,
            )
        }

    private fun parseTwoRowItem(renderer: JsonObject?): ShelfItem? {
        if (renderer == null) return null
        val title = renderer.o("title").runs()
        if (title.isBlank()) return null
        val endpoint = renderer.o("navigationEndpoint")
        val browseId = endpoint.o("browseEndpoint").s("browseId")
        // History/"Listen again" cards for tracks YouTube never catalogued
        // as a proper Song carry no watchEndpoint at all — just a browseId
        // to a "non-music audio track page" prefixed MPED<videoId>. That's
        // the actual video id, not a real browsable page.
        val videoId = endpoint.o("watchEndpoint").s("videoId")
            ?: browseId?.takeIf { it.startsWith("MPED") }?.removePrefix("MPED")
        val resolvedBrowseId = browseId?.takeUnless { it.startsWith("MPED") }
        val thumbnails = renderer.o("thumbnailRenderer").o("musicThumbnailRenderer")
            .o("thumbnail").a("thumbnails")
        val subtitle = renderer.o("subtitle").runs()
        // A card with no browse target is a playable track, not an album,
        // playlist or artist; widescreen art on one of those means it's a
        // music-video upload rather than the catalogue track, which the
        // player can now show — same test as parseResponsiveListItem's.
        val isVideo = resolvedBrowseId == null && videoId != null && (
            thumbnails.isNotSquare() ||
                renderer.s("aspectRatio")?.contains("16_9") == true
            )
        // An album/playlist billed as a video chart/compilation — "N videos"
        // in the subtitle, or "video" in the card's own title (e.g. "Daily
        // Top Music Videos") — is the same dead-end as in parseBrowseItem.
        // A plain track card is exempt: a song can legitimately be titled
        // "Video Games" without being a music-video upload.
        if (resolvedBrowseId != null &&
            !resolvedBrowseId.startsWith("VL") &&
            !resolvedBrowseId.startsWith("PL") &&
            !resolvedBrowseId.startsWith("MPRE") &&
            !resolvedBrowseId.startsWith("UC") &&
            (VIDEO_WORD.containsMatchIn(title) || VIDEO_WORD.containsMatchIn(subtitle))
        ) {
            return null
        }
        return ShelfItem(
            title = title,
            subtitle = subtitle,
            thumbnailUrl = thumbnails.best(),
            videoId = videoId,
            browseId = resolvedBrowseId,
            isVideo = isVideo,
        )
    }

    /**
     * The credit out of a shelf card's subtitle, which reads "Song • Chelsea
     * Wolfe" rather than just the artist — [parseTwoRowItem] keeps the whole
     * line because the card shows it as billed, but starting a radio off the
     * card and carrying that line into [Song.artist] would print the label
     * everywhere the field is read afterwards: the player, the mini player,
     * a shared link, a scrobble. Same split as [parseResponsiveListItem]'s
     * subtitle, so a "Song" or "Single" heading drops out the same way.
     */
    fun artistFromSubtitle(subtitle: String): String {
        val parts = subtitle.split(" • ").map(String::trim).filter { it.isNotBlank() }
        return parts.firstOrNull {
            it.lowercase() !in TYPE_WORDS && !it.matches(TALLY) && !it.matches(DURATION)
        } ?: subtitle
    }

    /**
     * Playlist-id prefixes nothing can be added to: `LM` is Liked Music (a
     * song joins it by being liked), `SE` is Episodes for Later, `RD` is a
     * generated radio mix, and `OLAK`/`MPRE` are albums wearing a playlist id.
     */
    private val NOT_EDITABLE = listOf("LM", "SE", "RD", "OLAK", "MPRE")

    /** YouTube nests this badge differently across search, album and queue renderers. */
    private fun JsonElement?.hasExplicitBadge(): Boolean? =
        true.takeIf {
            when (this) {
                is JsonPrimitive -> contentOrNull == "MUSIC_EXPLICIT_BADGE"
                is JsonArray -> any { it.hasExplicitBadge() == true }
                is JsonObject -> values.any { it.hasExplicitBadge() == true }
                null -> false
            }
        }

    private val DURATION = Regex("""\d+:\d{2}""")
    /** One unit of an episode's runtime — "2 hr", "43 min", "10 sec". */
    private val RUNTIME_PART = Regex("""(\d+)\s*(hours?|hr|min|sec)""", RegexOption.IGNORE_CASE)
    private val YEAR = Regex("""\d{4}""")
    /**
     * A counted quantity rather than a name — "12.4M plays", "13 songs",
     * "1 hour, 4 minutes". Deliberately narrow: it has to leave "21 Savage"
     * and "50 Cent" alone, so a number only disqualifies a segment when it is
     * counting one of the words YouTube counts with.
     */
    private val TALLY = Regex(
        """[\d.,]+\s*[KMB]?\s+(plays|views|likes|songs|tracks|subscribers|""" +
            """hours?|minutes?|seconds?)\b.*""",
        RegexOption.IGNORE_CASE,
    )
    /** Header words that mark a page as a release, whose rows share its credit. */
    private val RELEASE_WORDS = setOf("album", "single", "ep")
    private val HEADER_RENDERERS = listOf(
        "musicResponsiveHeaderRenderer",
        "musicDetailHeaderRenderer",
    )
    /** Header lines that name the artist, in either header shape. */
    private val HEADER_CREDIT_LINES = listOf("straplineTextOne", "subtitle")
    private val TYPE_WORDS = setOf(
        "song", "video", "album", "single", "ep", "artist",
        "playlist", "podcast", "episode",
    )
    /**
     * Flags a browse card as video content: "50 videos" in a subtitle
     * (instead of "50 songs"), or the word right in a title like
     * "Daily Top Music Videos".
     */
    private val VIDEO_WORD = Regex("""\bvideos?\b""", RegexOption.IGNORE_CASE)
}

// ---- Tiny JSON navigation helpers (null-safe, never throw) ------------------

private fun JsonElement?.o(key: String): JsonObject? =
    (this as? JsonObject)?.get(key) as? JsonObject

private fun JsonElement?.a(key: String): JsonArray? =
    (this as? JsonObject)?.get(key) as? JsonArray

private fun JsonElement?.s(key: String): String? =
    ((this as? JsonObject)?.get(key) as? JsonPrimitive)?.contentOrNull

/**
 * The first string under [key] anywhere in the subtree, by name rather than by
 * path — for a value whose position is not promised. See [InnertubeParser.parseAccountChannels].
 */
private fun JsonElement?.findString(key: String): String? = when (this) {
    is JsonObject -> {
        (this[key] as? JsonPrimitive)?.contentOrNull
            ?: values.firstNotNullOfOrNull { it.findString(key) }
    }
    is JsonArray -> firstNotNullOfOrNull { it.findString(key) }
    else -> null
}

/** Whether [key] appears as an object key anywhere in the subtree. */
private fun JsonElement?.hasKey(key: String): Boolean = when (this) {
    is JsonObject -> containsKey(key) || values.any { it.hasKey(key) }
    is JsonArray -> any { it.hasKey(key) }
    else -> false
}

/** Whether a row plays a podcast episode, by the type its play action states. */
private fun JsonObject.isPodcastEpisode(): Boolean =
    findString("musicVideoType") == "MUSIC_VIDEO_TYPE_PODCAST_EPISODE"

/** Whether a track row is one of the signed-in user's own uploads. */
private fun JsonObject.isPrivateUpload(): Boolean =
    hasKey("musicDeletePrivatelyOwnedEntityCommand") ||
        findString("musicVideoType")?.contains("PRIVATELY_OWNED", ignoreCase = true) == true

private fun JsonElement?.runs(): String =
    this.a("runs")?.joinToString("") { it.s("text").orEmpty() }.orEmpty()

/** The first run's text alone — for a field that is a count or a label, never a sentence. */
private fun JsonElement?.firstRunText(): String? =
    this.a("runs")?.firstOrNull().s("text")

/**
 * Last thumbnail is the largest, taken exactly as offered.
 *
 * This used to rewrite the size hint up to 544px on the way past, on the
 * reasoning that YouTube will serve any size asked for and bigger is better.
 * It is, for the one image drawn full-screen — and it is wasteful for every
 * other, which is most of them: YouTube offers a search row's cover at 120px
 * for 7.8kB and will happily serve the same cover at 544px for 84kB, to fill
 * a square the size of a fingertip.
 *
 * So the size is now decided where the image is drawn rather than here, by
 * [com.music.bitchord.data.model.artworkAt] — which trades up just as freely
 * as it trades down, and is what the player calls.
 */
private fun JsonArray?.best(): String? = this?.lastOrNull().s("url")

/**
 * Catalogue art is always square; a music-video upload's thumbnail is
 * widescreen. Missing dimensions default to "square" so a row is never
 * dropped just because the field wasn't present.
 */
private fun JsonArray?.isNotSquare(): Boolean {
    val last = this?.lastOrNull()
    val width = last.s("width")?.toDoubleOrNull() ?: return false
    val height = last.s("height")?.toDoubleOrNull() ?: return false
    if (width <= 0 || height <= 0) return false
    return width / height !in 0.85..1.15
}
